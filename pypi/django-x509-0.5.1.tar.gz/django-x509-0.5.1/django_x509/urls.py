'''
There are no urls in this file. It has no functional use.
This file exists only to maintain backward compatibility.
'''

app_name = 'x509'  # pragma: no cover
urlpatterns = []   # pragma: no cover
